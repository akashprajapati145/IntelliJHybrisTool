package labclasses;

public class Hello {
    public int add(int a, int b) {
        int sum = a + b;
        return sum;
    }
}
