package com.javaoptimizerai;

import com.github.weisj.jsvg.C;
import com.intellij.openapi.project.Project;
import com.intellij.ui.components.JBScrollPane;
import com.intellij.ui.components.JBTextArea;

import javax.swing.*;
import java.awt.*;
import java.time.LocalTime;

public class AIOptimizerPanel extends JPanel {
    private final JTextArea inputArea;
    private final JTextArea outputArea;
    private final JButton optimizeButton;
    private final JButton generateTestButton;
    private final AIService aiService;

    public AIOptimizerPanel(Project project) {
        this.setLayout(new BorderLayout());
        aiService = new AIService();

        // === CODE OPTIMIZER TAB ===
        inputArea = new JBTextArea(15, 60);
        inputArea.setLineWrap(true);
        inputArea.setWrapStyleWord(true);

        outputArea = new JBTextArea(15, 60);
        outputArea.setLineWrap(true);
        outputArea.setWrapStyleWord(true);
        outputArea.setEditable(false);

        JBScrollPane inputScrollPane = new JBScrollPane(inputArea);
        JBScrollPane outputScrollPane = new JBScrollPane(outputArea);

        JPanel ioPanel = new JPanel(new GridLayout(2, 1));
        ioPanel.add(inputScrollPane);
        ioPanel.add(outputScrollPane);

        optimizeButton = new JButton("Optimize Code");
        generateTestButton = new JButton("Generate Unit Test");

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        buttonPanel.add(optimizeButton);
        buttonPanel.add(generateTestButton);

        JPanel codeOptimizerPanel = new JPanel(new BorderLayout());
        codeOptimizerPanel.add(ioPanel, BorderLayout.CENTER);
        codeOptimizerPanel.add(buttonPanel, BorderLayout.SOUTH);

        optimizeButton.addActionListener(e -> {
            String code = inputArea.getText().trim();
            if (code.isEmpty()) {
                outputArea.setText("Please enter some Java code.");
                return;
            }

            outputArea.setText("Optimizing code...");
            new Thread(() -> {
                String result = aiService.optimizeCode(code);
                SwingUtilities.invokeLater(() ->
                        outputArea.setText(result != null ? result : "Optimization failed.")
                );
            }).start();
        });

        generateTestButton.addActionListener(e -> {
            String code = inputArea.getText().trim();
            if (code.isEmpty()) {
                outputArea.setText("Please enter some Java code.");
                return;
            }

            outputArea.setText("Generating unit test...");
            new Thread(() -> {
                String result = aiService.generateUnitTests(code);
                SwingUtilities.invokeLater(() ->
                        outputArea.setText(result != null ? result : "Test generation failed.")
                );
            }).start();
        });

        // === HYBRIS ASSISTANT TAB ===
        JPanel hybrisAssistantPanel = new JPanel(new BorderLayout());

        JTextArea chatArea = new JBTextArea(15, 60);
        chatArea.setEditable(false);
        chatArea.setLineWrap(true);
        chatArea.setWrapStyleWord(true);
        chatArea.setBackground(UIManager.getColor("EditorPane.background"));
        chatArea.setForeground(UIManager.getColor("Label.foreground"));
        JTextArea hybrisQuestionArea = new JBTextArea(4, 50);
        hybrisQuestionArea.setLineWrap(true);
        hybrisQuestionArea.setWrapStyleWord(true);

        JButton askHybrisButton = new JButton("Ask Hybris Assistant");

        askHybrisButton.addActionListener(e -> {
            String question = hybrisQuestionArea.getText().trim();
            if (!question.isEmpty()) {
                appendChat(chatArea, "You", question);
                hybrisQuestionArea.setText("");
                appendChat(chatArea, "Hybris Assistant", "Thinking...");

                new Thread(() -> {
                    String hybrisPrompt = """
You are a SAP Hybris commerce expert with deep knowledge of the Hybris platform, including:
- Backoffice customization
- Data modeling using items.xml
- Services and facades
- Integration with SAP ERP, S/4HANA
- Workflow, CronJobs, ImpEx, and OCC webservices

Only respond with SAP Commerce Cloud best practices. Answer this question:
""" + question;

                    String answer = aiService.askHybrisExpert(hybrisPrompt);
                    SwingUtilities.invokeLater(() -> {
                        removeLastChat(chatArea); // remove "Thinking..."
                        appendChat(chatArea, "Hybris Assistant", answer != null ? answer : "No answer received.");
                    });
                }).start();
            }
        });

        JPanel hybrisInputPanel = new JPanel(new BorderLayout());
        hybrisInputPanel.add(new JScrollPane(hybrisQuestionArea), BorderLayout.CENTER);
        hybrisInputPanel.add(askHybrisButton, BorderLayout.EAST);

        hybrisAssistantPanel.add(new JScrollPane(chatArea), BorderLayout.CENTER);
        hybrisAssistantPanel.add(hybrisInputPanel, BorderLayout.SOUTH);

        // === TABS ===
        JTabbedPane tabbedPane = new JTabbedPane();
        tabbedPane.addTab("Code Optimizer", codeOptimizerPanel);
        tabbedPane.addTab("Hybris Assistant", hybrisAssistantPanel);

        this.add(tabbedPane, BorderLayout.CENTER);
    }

    private void appendChat(JTextArea chatArea, String sender, String message) {
        String timestamp = LocalTime.now().withNano(0).toString();
        chatArea.append(String.format("[%s] %s: %s%n%n", timestamp, sender, message));
    }

    private void removeLastChat(JTextArea chatArea) {
        String content = chatArea.getText();
        int lastIndex = content.lastIndexOf("Hybris Assistant:");
        if (lastIndex != -1) {
            chatArea.setText(content.substring(0, lastIndex).trim() + "\n\n");
        }
    }
}
