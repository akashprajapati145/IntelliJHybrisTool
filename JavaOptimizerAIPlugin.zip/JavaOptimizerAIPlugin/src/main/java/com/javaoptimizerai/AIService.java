package com.javaoptimizerai;

import org.json.JSONObject;

import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

public class AIService {

    private static final String OLLAMA_API_URL = "http://localhost:11434/api/generate";
    private static final String MODEL = "codellama";

    public static String optimizeCode(String code) {
        String prompt = "You are a Java expert. Optimize the following Java code. Only return the optimized Java code:\n\n" + code;
        return sendPrompt(prompt);
    }

    public static String generateUnitTests(String code) {
        String prompt = "You are a Java expert. Generate JUnit 5 test cases for the following Java code:\n\n" + code;
        return sendPrompt(prompt);
    }

    private static String sendPrompt(String prompt) {
        try {
            URL url = new URL(OLLAMA_API_URL);
            HttpURLConnection con = (HttpURLConnection) url.openConnection();
            con.setRequestMethod("POST");
            con.setRequestProperty("Content-Type", "application/json");
            con.setDoOutput(true);

            String body = "{ \"model\": \"" + MODEL + "\", \"prompt\": " + jsonEscape(prompt) + ", \"stream\": false }";
            try (OutputStream os = con.getOutputStream()) {
                os.write(body.getBytes(StandardCharsets.UTF_8));
            }

            try (BufferedReader reader = new BufferedReader(new InputStreamReader(con.getInputStream()))) {
                StringBuilder response = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) {
                    response.append(line).append("\n");
                }

                // Extract "response" field from JSON
                String responseBody = response.toString();
                int start = responseBody.indexOf("\"response\":\"") + 11;
                int end = responseBody.indexOf("\",\"done\"");
                if (start > 0 && end > start) {
                    String extracted = responseBody.substring(start, end);
                    return extracted.replace("\\n", "\n").replace("\\\"", "\"");
                }

                return response.toString();
            }

        } catch (Exception e) {
            return "Error: " + e.getMessage();
        }
    }

    private static String jsonEscape(String s) {
        return "\"" + s.replace("\\", "\\\\")
                .replace("\"", "\\\"")
                .replace("\n", "\\n")
                .replace("\r", "") + "\"";
    }

    public String askHybrisExpert(String prompt) {
        try {
            JSONObject requestBody = new JSONObject();
            requestBody.put("model", "codellama");
            requestBody.put("prompt", prompt);
            requestBody.put("stream", false);

            HttpURLConnection con = (HttpURLConnection) new URL("http://localhost:11434/api/generate").openConnection();
            con.setRequestMethod("POST");
            con.setRequestProperty("Content-Type", "application/json");
            con.setDoOutput(true);

            OutputStream os = con.getOutputStream();
            os.write(requestBody.toString().getBytes(StandardCharsets.UTF_8));
            os.close();

            BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
            String inputLine;
            StringBuilder content = new StringBuilder();
            while ((inputLine = in.readLine()) != null) {
                content.append(inputLine);
            }
            in.close();

            JSONObject jsonResponse = new JSONObject(content.toString());
            return jsonResponse.optString("response", "No response received.");
        } catch (Exception e) {
            return "Error from Hybris Assistant: " + e.getMessage();
        }
    }


}
